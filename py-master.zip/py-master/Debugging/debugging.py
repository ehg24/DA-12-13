def add_num(a,b):
    '''Return sum of two numbers'''
    s=a+b
    return s

n1=input('enter first number:')
n1=int(n1)
n2=input('enter second number:')
n2=int(n2)
s = add_num(n1,n2)
print ('sum is: ',s);