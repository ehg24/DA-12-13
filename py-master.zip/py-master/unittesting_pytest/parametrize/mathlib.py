def calc_square(num):
    return num*num